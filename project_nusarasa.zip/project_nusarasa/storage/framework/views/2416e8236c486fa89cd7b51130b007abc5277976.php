
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <div class="p-5 text-white text-center rounded bg-image d-flex justify-content-center align-items-center flex-column vh-100"
            style="margin-left: -12px; margin-right: -12px;">
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="card mt-3 border-0">
            <div class="card-header text-center bg-transparent border-0 fs-1">Search Your Favorite Food!</div>
            <div class="card-body">
                <div class="card-text mt-3 mb-5">
                    <form class="d-flex" role="search" action="/search" method="GET">
                        <input class="form-control me-2" type="search" placeholder="Search" name="search" aria-label="Search"
                            value="<?php echo e(old('search')); ?>" autocomplete="off">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </form>
                </div>
                <div class="row row-cols-1 row-cols-md-4 g-4">
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card">
                                <img src="<?php echo e(asset('assets/img/' . $item->image)); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($item->nama_product); ?></h5>
                                    <p class="card-text">Rp<?php echo e(number_format($item->harga, 0, ',', '.')); ?></p>
                                    <a href="/detail-product/<?php echo e($item->id); ?>" class="btn btn-primary">More Detail</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-2">
                    <?php echo e($product->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gagas\Documents\Semester 5\Web Programming\LECTURE PROJECT\LECTURE PROJECT\project_nusarasa\resources\views/search.blade.php ENDPATH**/ ?>