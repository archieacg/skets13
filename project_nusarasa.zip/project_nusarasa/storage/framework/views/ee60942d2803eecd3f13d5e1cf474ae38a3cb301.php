
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/img/' . $result->image)); ?>" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title fs-1 text-capitalize"><?php echo e($result->nama_product); ?></h5>
                                <p class="card-text fs-5 fw-bold">Rp.
                                    <?php echo e(number_format($result->harga, 0, ',', '.')); ?>

                                </p>
                                <p class="card-text fs-5 fw-bold">Sisa Stok : <?php echo e($result->qty); ?></p>
                                <hr>
                                <p class="card-text fs-5 fw-bold">Product Detail</p>
                                <p class="card-text"><?php echo e($result->detail); ?></p>
                                <hr style="height: 10px">
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->role == 'admin'): ?>
                                        <div class="row">
                                            <div class="col-4"><a href="/home" class="btn btn-danger w-100">Back</a></div>
                                            <div class="col-3">
                                                <form action="<?php echo e(url('product/' . $result->id)); ?>" method="post"
                                                    onsubmit="return confirm('Apakah anda yakin ingin menghapus?')">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-danger shadow">Delete Item</button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <p class="card-text fs-5 fw-bold">Quantity :</p>
                                        <form class="row g-3">
                                            <div class="col-4">
                                                <label for="qty" class="visually-hidden"></label>
                                                <input type="number" class="form-control" id="qty" placeholder="0"
                                                    minlength="1">
                                            </div>
                                            <div class="col-3">
                                                <button type="submit" class="btn btn-success mb-3 w-100">Add To Cart</button>
                                            </div>
                                        </form>
                                        <div class="row">
                                            <div class="col-4"><a href="/home" class="btn btn-danger w-100">Back</a></div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gagas\Documents\Semester 5\Web Programming\LECTURE PROJECT\LECTURE PROJECT\project_nusarasa\resources\views/detail-product.blade.php ENDPATH**/ ?>