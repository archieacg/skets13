<?php $__env->startSection('content'); ?>
    <div class="card mt-3 text-center h1">
        <div class="card-body">Selamat Datang Di Halaman Utama</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectLAB\resources\views/Home.blade.php ENDPATH**/ ?>