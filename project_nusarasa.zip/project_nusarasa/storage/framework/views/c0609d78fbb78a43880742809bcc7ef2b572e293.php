
<?php $__env->startSection('content'); ?>
    <div class="text-center h2 mt-3">Check What You've Bought</div>
    <div class="card mt-5">
        <div class="card-body">
            <p class="card-text fs-5 fw-bold">2022-05-31</p>
            <ul>
                <li>1 pc(s) Yellow T-Shirt Rp10.000</li>
                <li>1 pc(s) Brown T-Shirt Rp10.000</li>
            </ul>
            <p class="card-text fs-5 fw-bold">Total Price 20.000</p>
        </div>
    </div>
    <div class="card mt-2">
        <div class="card-body">
            <p class="card-text fs-5 fw-bold">2022-05-31</p>
            <ul>
                <li>1 pc(s) Yellow T-Shirt Rp10.000</li>
            </ul>
            <p class="card-text fs-5 fw-bold">Total Price 10.000</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectLAB\resources\views/history.blade.php ENDPATH**/ ?>