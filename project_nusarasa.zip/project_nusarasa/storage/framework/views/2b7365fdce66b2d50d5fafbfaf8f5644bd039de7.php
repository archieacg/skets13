<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('auth.templates.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <main class="form-signin w-100 m-auto">
        <div class="card p-5" style="background-color: #d88139">
            <div class="card-body">
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                        <h1 class="h3 mb-3 fw-normal">Form <?php echo e($title); ?></h1>
                    </div>
                    <div class="form-floating mb-2">
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                            id="email" value="<?php echo e(old('email')); ?>" autocomplete="off" required>
                        <label for="email">Email address</label>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <p><?php echo e($message); ?></p>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating">
                        <input type="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="password" id="password" autocomplete="off" required>
                        <label for="password">Password</label>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <p><?php echo e($message); ?></p>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="checkbox mb-3 text-center text-white">
                        <label>
                            <input type="checkbox" value="remember-me"> Remember me
                        </label>
                    </div>
                    <div class="text-center">
                        <button class="w-25 btn btn-light mb-3 rounded-4" type="submit">Sign in</button>
                    </div>
                    <div class="form-text d-flex justify-content-between">
                        <div class="text-white">Don’t have an account? <a href="/register"
                                class="text-decoration-none text-dark">
                                Sign
                                up</a></div>
                        <div><a href="" class="text-decoration-none text-dark">Forget password</a></div>
                    </div>
                </form>
            </div>
        </div>
    </main>


    <?php echo $__env->make('auth.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

</body>

</html>
<?php /**PATH C:\xampp\htdocs\project_nusarasa\resources\views/auth/login.blade.php ENDPATH**/ ?>