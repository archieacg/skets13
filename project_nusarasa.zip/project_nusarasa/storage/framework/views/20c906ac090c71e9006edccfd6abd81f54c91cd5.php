
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <div class="p-5 text-white text-center rounded bg-image d-flex justify-content-center align-items-center flex-column vh-100"
            style="margin-left: -12px; margin-right: -12px;">
            <div class="h1">Welcome To My Web Shopping</div>
            <div class="fs-5">Online Shopping No. 1</div>
            <div><a href="/register" class="btn btn-primary rounded mt-3">SIGN UP NOW</a></div>
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="card mt-3 border-0">
            <div class="card-header text-center bg-transparent border-0 fs-1">Cart</div>
            <div class="card-body">
                <div class="card-title bg-transparent border-0 fs-2 d-flex align-items-center justify-content-end">
                    <div style="margin-right: 20px">Total Price:
                        <?php echo e(number_format($product[0]['harga'] + $product[1]['harga'], 0, ',', '.')); ?></div>
                    <a href="/checkout" class="btn btn-primary btn-sm">Check Out(4)</a>
                </div>
                <div class="row row-cols-1 row-cols-md-4 g-4">
                    <div class="col">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/img/' . $product[0]['image'])); ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product[0]['nama_product']); ?></h5>
                                <p class="card-text">Rp<?php echo e(number_format($product[0]['harga'], 0, ',', '.')); ?></p>
                                <a href="/edit-product/<?php echo e($product[0]['id']); ?>" class="btn btn-primary">Edit Cart</a>
                                <a href="/detail-product/<?php echo e($product[0]['id']); ?>" class="btn btn-danger">Remove from Cart</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="<?php echo e(asset('assets/img/' . $product[0]['image'])); ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product[1]['nama_product']); ?></h5>
                                <p class="card-text">Rp<?php echo e(number_format($product[1]['harga'], 0, ',', '.')); ?></p>
                                <a href="/detail-product/<?php echo e($product[1]['id']); ?>" class="btn btn-primary">Edit Cart</a>
                                <a href="/detail-product/<?php echo e($product[1]['id']); ?>" class="btn btn-danger">Remove from Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-2">
                    <?php echo e($product->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_nusarasa\resources\views/cart.blade.php ENDPATH**/ ?>