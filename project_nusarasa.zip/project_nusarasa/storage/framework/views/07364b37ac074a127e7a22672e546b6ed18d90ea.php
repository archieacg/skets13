
<?php $__env->startSection('content'); ?>
    <div class="card mt-3">
        <div class="card-header fs-5">Show Product</div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Detail</th>
                        <th scope="col">Size</th>
                        <th scope="col">Qty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1 ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($no++); ?></th>
                            <td><?php echo e($data->Nama_Produk); ?></td>
                            <td>Rp<?php echo e(number_format($data->Harga_Produk, 0, ',', '.')); ?></td>
                            <td><?php echo e($data->Detail_Produk); ?></td>
                            <td><?php echo e($data->Size_Produk); ?></td>
                            <td><?php echo e($data->Qty_Produk); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project_nusarasa\resources\views/product.blade.php ENDPATH**/ ?>