
<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <div id="carouselExampleSlidesOnly" class="carousel" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo e(asset('assets/img/background.png')); ?>" class="d-block w-100" height="500px">
                </div>
            </div>
        </div>
        <div style="border: 5px solid #f3a22d"></div>
        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kategori Jajanan</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card">
                            <img src="https://via.placeholder.com/640x480.png/0055cc?text=Kue+Kering" class="card-img-top"
                                alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Kering</p>
                                <a href="" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="https://via.placeholder.com/640x480.png/0055cc?text=Kue+Basah" class="card-img-top"
                                alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Basah</p>
                                <a href="" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="https://via.placeholder.com/640x480.png/0055cc?text=Gorengan" class="card-img-top"
                                alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Gorengan</p>
                                <a href="" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>

        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kue Kering</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <?php $__currentLoopData = $product_best; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card">
                                <img src="<?php echo e($item->image); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($item->nama_product); ?></h5>
                                    <p class="card-text">Rp<?php echo e(number_format($item->harga, 0, ',', '.')); ?></p>
                                    <a href="/detail-product/<?php echo e($item->id); ?>" class="btn btn-primary">More Detail</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <div style="border: 5px solid #f3a22d"></div>
        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kategori Jajanan</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card">
                            <img src="https://via.placeholder.com/640x480.png/0055cc?text=Kue+Kering" class="card-img-top"
                                alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Kering</p>
                                <a href="" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="https://via.placeholder.com/640x480.png/0055cc?text=Kue+Basah" class="card-img-top"
                                alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Basah</p>
                                <a href="" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="https://via.placeholder.com/640x480.png/0055cc?text=Gorengan" class="card-img-top"
                                alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Gorengan</p>
                                <a href="" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>

        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kue Kering</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <?php $__currentLoopData = $product_best; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card">
                                <img src="<?php echo e($item->image); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($item->nama_product); ?></h5>
                                    <p class="card-text">Rp<?php echo e(number_format($item->harga, 0, ',', '.')); ?></p>
                                    <a href="/detail-product/<?php echo e($item->id); ?>" class="btn btn-primary">More Detail</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectLAB\resources\views/shop.blade.php ENDPATH**/ ?>