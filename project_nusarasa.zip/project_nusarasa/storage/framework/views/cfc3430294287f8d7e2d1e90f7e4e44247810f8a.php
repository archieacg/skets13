
<?php $__env->startSection('content'); ?>
    <div class="container w-50">
        <div class="card my-5 ">
            <div class="card-header fs-3 fw-bold text-center bg-transparent border-0">My Profile</div>
            <div class="card-body text-center">
                <h5><span class="badge bg-secondary text-capitalize"><?php echo e(auth()->user()->role); ?></span></h4>
                    <p class="card-text fs-6">
                        <span class="fw-bold">Name: <?php echo e(auth()->user()->name); ?></span> <br>
                        <?php echo e(auth()->user()->email); ?> <br>
                    </p>
            </div>
            <div class="card-footer text-center bg-transparent border-0">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->role == 'admin'): ?>
                        <a href="/password" class="btn btn-outline-info">Edit Password</a>
                    <?php else: ?>
                        <a href="/edit-profile/<?php echo e(auth()->user()->id); ?>" class="btn btn-primary" style="margin-right: 10px">Edit
                            Profile</a>
                        <a href="/password" class="btn btn-outline-info">Edit Password</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project_nusarasa\resources\views/profile.blade.php ENDPATH**/ ?>