<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'products';

    protected $fillable = [
        'nama_product', 'harga', 'detail', 'qty', 'kategori_id', 'image'
    ];

    public function user()
    {
        return $this->hasMany(User::class);
    }
}
