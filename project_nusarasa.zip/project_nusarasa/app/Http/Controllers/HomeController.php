<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function index()
    {
        $data = [
            'title' => 'Home',
            'product_best' => Product::limit(3)->get(),
        ];
        return view('home', $data);
    }

    public function shop()
    {
        $data = [
            'title' => 'Shop',
            'product_best' => Product::paginate(6),
        ];
        return view('shop', $data);
    }

    public function kategori_kue_kering()
    {
        $data = [
            'title' => 'Shop | Kategori Kue Kering',
            'product_best' => Product::where('kategori_id', 1)->paginate(6),
        ];
        return view('shop-kategori-kue-kering', $data);
    }

    public function kategori_kue_basah()
    {
        $data = [
            'title' => 'Shop | Kategori Kue Basah',
            'product_best' => Product::where('kategori_id', 2)->paginate(6),
        ];
        return view('shop-kategori-kue-basah', $data);
    }

    public function kategori_gorengan()
    {
        $data = [
            'title' => 'Shop | Kategori Gorengan',
            'product_best' => Product::where('kategori_id', 3)->paginate(6),
        ];
        return view('shop-kategori-gorengan', $data);
    }

    public function cart()
    {
        $data = [
            'title' => 'Cart',
            'product' => Product::paginate(8)
        ];
        return view('cart', $data);
    }

    public function checkout()
    {
        $data = [
            'title' => 'Checkout',
            'product' => Product::paginate()
        ];
        return view('checkout', $data);
    }

    public function checkout_action()
    {
        return redirect()->route('search')->with('success', 'Thank For Shopping!');
    }

    public function show(Product $product)
    {
        $data = [
            'title' => 'Edit Product',
            'result' => $product
        ];
        return view('edit-product', $data);
    }

    public function history()
    {
        $data = [
            'title' => 'History',
        ];
        return view('history', $data);
    }

    public function edit_password()
    {
        $data = [
            'title' => 'Edit Password',
        ];
        return view('edit-password', $data);
    }

    public function search(Request $request)
    {
        $search = $request->search;
        if ($search == "") {
            $data = [
                'title' => 'Search',
                'product' => Product::paginate(8)
            ];

            return view('search', $data);
        } else {
            $data = [
                'title' => 'Search',
                'product' => Product::where('nama_product', 'like', '%' . $search . '%')->paginate(8)
            ];

            return view('search', $data);
        }
    }
}
