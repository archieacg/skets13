<!doctype html>
<html lang="en">

<head>
    @include('auth.templates.head')
</head>

<body>

    <main class="form-signin w-100 m-auto">
        <div class="card p-5" style="background-color: #d88139">
            <div class="card-body">
                <form action="{{ route('register.action') }}" method="POST">
                    @csrf
                    <div class="text-center">
                        <h1 class="h3 mb-3 fw-normal">Form {{ $title }}</h1>
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                            id="name" value="{{ old('name') }}" placeholder="Enter your name" autocomplete="off"
                            required>
                        @error('name')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <input type="email" class="form-control @error('email') is-invalid @enderror" name="email"
                            id="email" value="{{ old('email') }}" placeholder="Enter your mail" autocomplete="off"
                            required>
                        @error('email')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control @error('password') is-invalid @enderror"
                            name="password" id="password" placeholder="Enter your password" autocomplete="off"
                            required>
                        @error('password')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control @error('password_confirm') is-invalid @enderror"
                            name="password_confirm" id="password_confirm" placeholder="Confirm your password"
                            autocomplete="off" required>
                        @error('password_confirm')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="text-center">
                        <button class="w-25 btn btn-light rounded-4" type="submit">Register</button>
                    </div>
                    <div class="form-text text-white text-center">Already have an account? <a href="/login"
                            class="text-decoration-none text-dark"> Sign
                            in</a>
                    </div>
                </form>
            </div>
        </div>

    </main>


    @include('auth.templates.footer');

</body>

</html>
