<!doctype html>
<html lang="en">

<head>
    @include('auth.templates.head')
</head>

<body>

    <main class="form-signin w-100 m-auto">
        <div class="card p-5" style="background-color: #d88139">
            <div class="card-body">
                <form action="{{ route('login') }}" method="POST">
                    @csrf
                    <div class="text-center">
                        <h1 class="h3 mb-3 fw-normal">Form {{ $title }}</h1>
                    </div>
                    <div class="form-floating mb-2">
                        <input type="email" class="form-control @error('email') is-invalid @enderror" name="email"
                            id="email" value="{{ old('email') }}" autocomplete="off" required>
                        <label for="email">Email address</label>
                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <p>{{ $message }}</p>
                            </span>
                        @enderror
                    </div>
                    <div class="form-floating">
                        <input type="password" class="form-control  @error('password') is-invalid @enderror"
                            name="password" id="password" autocomplete="off" required>
                        <label for="password">Password</label>
                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <p>{{ $message }}</p>
                            </span>
                        @enderror
                    </div>

                    <div class="checkbox mb-3 text-center text-white">
                        <label>
                            <input type="checkbox" value="remember-me"> Remember me
                        </label>
                    </div>
                    <div class="text-center">
                        <button class="w-25 btn btn-light mb-3 rounded-4" type="submit">Sign in</button>
                    </div>
                    <div class="form-text d-flex justify-content-between">
                        <div class="text-white">Don’t have an account? <a href="/register"
                                class="text-decoration-none text-dark">
                                Sign
                                up</a></div>
                        <div><a href="" class="text-decoration-none text-dark">Forget password</a></div>
                    </div>
                </form>
            </div>
        </div>
    </main>


    @include('auth.templates.footer');

</body>

</html>
