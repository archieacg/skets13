@extends('app')
@section('content')
    @guest()
        <div class="p-5 text-white text-center rounded bg-image d-flex justify-content-center align-items-center flex-column vh-100"
            style="margin-left: -12px; margin-right: -12px;">
            <div class="h1">Welcome To My Web Shopping</div>
            <div class="fs-5">Online Shopping No. 1</div>
            <div><a href="/register" class="btn btn-primary rounded mt-3">SIGN UP NOW</a></div>
        </div>
    @endguest

    @auth()
        <div class="card mt-3 border-0">
            <div class="card-header text-center bg-transparent border-0 fs-1">Cart</div>
            <div class="card-body container">
                <table class="table table-hover table-sm">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Harga Satuan</th>
                            <th>Total Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{ $product[0]['nama_product'] }}</td>
                            <td>Rp{{ number_format($product[0]['harga'], 0, ',', '.') }}</td>
                            <td>Rp{{ number_format($product[0]['harga'], 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <td>{{ $product[1]['nama_product'] }}</td>
                            <td>Rp{{ number_format($product[1]['harga'], 0, ',', '.') }}</td>
                            <td>Rp{{ number_format($product[1]['harga'], 0, ',', '.') }}</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2">Subtotal</td>
                            <td>Rp{{ number_format(20000, 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <td colspan="2">Ongkir</td>
                            <td>Rp{{ number_format($product[1]['harga'] + $product[1]['harga'] + 20000, 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <td colspan="2">Pilih Metode Pembayaran</td>
                            <td>
                                <select class="form-select form-select-sm" name="id_pembayaran">
                                    <option value="BCA a/n Lesti Lestari">BCA a/n Lesti Lestari</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                Upload Bukti Pembayaran
                                <div class="form-text h6">(kosongkan jika metode pembayaran COD)</div>
                            </td>
                            <td>
                                <input class="form-control form-control-sm" id="formFileSm" name="upload_bukti" type="file">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" class="text-center">
                                Harap melampirkan bukti pembayaran sebelum menekan tombol Selesaikan Pembayaran.
                                <div>Jika tidak melampirkan bukti pembayaran maka otomatis pesanan anda akan ditolak.</div>
                            </td>
                        </tr>
                    </tfoot>
                </table>
                <div class="col-12 text-right">
                    <a href="/cart" class="btn btn-outline-secondary">Kembali Kekeranjang</a>
                    <a href="/checkout/store" class="btn btn-outline-success">Selesaikan Pembayaran</a>
                </div>
            </div>
        </div>
    @endauth
@endsection
