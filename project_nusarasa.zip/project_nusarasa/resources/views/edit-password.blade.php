@extends('app')
@section('content')
    <div class="container">
        <div class="card mt-5">
            <div class="card-body m-5">
                <form action="" method="POST">
                    @csrf
                    <div class="text-center">
                        <h1 class="h3 mb-3 fw-normal">Update Profile</h1>
                    </div>
                    <div class="mb-3">
                        <label for="old_password" class="form-label">Old Password <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('old_password') is-invalid @enderror"
                            name="old_password" id="old_password" autocomplete="off" required placeholder="(5-20 letters)">
                        @error('old_password')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('new_password') is-invalid @enderror"
                            name="new_password" id="new_password" autocomplete="off" required placeholder="(5-20 letters)">
                        @error('new_password')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <button class="w-100 btn btn-success" type="submit">Save Update</button>
                    <div class="form-text"><a href="/profile" class="btn btn-danger"> Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
