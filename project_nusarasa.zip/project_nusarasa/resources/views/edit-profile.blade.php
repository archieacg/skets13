@extends('app')
@section('content')
    <div class="container">
        <div class="card mt-5">
            <div class="card-body m-5">
                <form action="/edit-profile/{{ $result->id }}" method="POST">
                    @csrf
                    <div class="text-center">
                        <h1 class="h3 mb-3 fw-normal">Update Profile</h1>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                            id="name" value="{{ $result->name }}" autocomplete="off" required>
                        @error('name')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address <span class="text-danger">*</span></label>
                        <input type="email" class="form-control @error('email') is-invalid @enderror" name="email"
                            id="email" value="{{ $result->email }}" autocomplete="off" required>
                        @error('email')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <button class="w-100 btn btn-success" type="submit">Save Update</button>
                    <div class="form-text"><a href="/profile" class="btn btn-danger"> Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
