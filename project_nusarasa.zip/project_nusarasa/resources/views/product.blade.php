@extends('app')
@section('content')
    <div class="card mt-3">
        <div class="card-header fs-5">Show Product</div>
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Detail</th>
                        <th scope="col">Size</th>
                        <th scope="col">Qty</th>
                    </tr>
                </thead>
                <tbody>
                    @php $no = 1 @endphp
                    @foreach ($result as $data)
                        <tr>
                            <th scope="row">{{ $no++ }}</th>
                            <td>{{ $data->Nama_Produk }}</td>
                            <td>Rp{{ number_format($data->Harga_Produk, 0, ',', '.') }}</td>
                            <td>{{ $data->Detail_Produk }}</td>
                            <td>{{ $data->Size_Produk }}</td>
                            <td>{{ $data->Qty_Produk }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
