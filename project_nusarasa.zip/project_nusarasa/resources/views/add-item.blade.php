@extends('app')
@section('content')
    <div class="container w-50">
        <div class="card mt-5 mb-5">
            <div class="card-body m-5">
                <form action="/add-item/store" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="text-center">
                        <h1 class="h3 mb-3 fw-normal">Add Item</h1>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                            id="name" autocomplete="off" required placeholder="(5-20 letters)"
                            value="{{ old('name') }}">
                        @error('name')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Price <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('price') is-invalid @enderror" name="price"
                            id="price" autocomplete="off" required placeholder="> 1000" value="{{ old('price') }}">
                        @error('price')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="desc" class="form-label">Desc <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('desc') is-invalid @enderror" name="desc"
                            id="desc" autocomplete="off" required placeholder="(min 5 letters)"
                            value="{{ old('desc') }}">
                        @error('desc')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="stock" class="form-label">Stock <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('stock') is-invalid @enderror" name="stock"
                            id="stock" autocomplete="off" required placeholder="> 1" value="{{ old('stock') }}">
                        @error('stock')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
                        <select name="category_id" id="category_id"
                            class="form-control @error('category_id') is-invalid @enderror" required>
                            <option value="">--- Select Category ---</option>
                            <option value="1">Kue Kering</option>
                            <option value="2">Kue Basah</option>
                            <option value="3">Gorengan</option>
                        </select>
                        @error('category_id')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Image <span class="text-danger">*</span></label>
                        <input type="file" class="form-control @error('image') is-invalid @enderror" name="image"
                            id="image" autocomplete="off" required placeholder="(5-20 letters)">
                        @error('image')
                            <div class="form-text">{{ $message }}</div>
                        @enderror
                    </div>
                    <button class="btn btn-danger" type="submit">Add</button>
                </form>
            </div>
        </div>
    </div>
@endsection
