@extends('app')
@section('content')
    @guest()
        <div id="carouselExampleSlidesOnly" class="carousel" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="{{ asset('assets/img/logo.png') }}" class="d-block w-100" height="500px">
                </div>
            </div>
        </div>
        <div style="border: 5px solid #f3a22d"></div>
        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kategori Jajanan</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('assets/img/kue-kering.png') }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Kering</p>
                                <a href="/shop/kategori/kue-kering" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('assets/img/kue-basah.png') }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Basah</p>
                                <a href="/shop/kategori/kue-basah" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('assets/img/gorengan.png') }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Gorengan</p>
                                <a href="/shop/kategori/gorengan" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- <div class="mt-2">
                    {{ $product->links() }}
                </div> --}}
            </div>
        </div>
    @endguest

    @auth()
        <div style="border: 5px solid #f3a22d"></div>
        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kategori Jajanan</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('assets/img/kue-kering.png') }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Kering</p>
                                <a href="/shop/kategori/kue-kering" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('assets/img/kue-basah.png') }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Kue Basah</p>
                                <a href="/shop/kategori/kue-basah" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card">
                            <img src="{{ asset('assets/img/gorengan.png') }}" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title h5">Gorengan</p>
                                <a href="/shop/kategori/gorengan" class="btn btn-primary">Lihat Jenis</a>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- <div class="mt-2">
                    {{ $product->links() }}
                </div> --}}
            </div>
        </div>

        <div class="card mt-3 border-0 text-center">
            <div class="card-header text-center bg-transparent border-0 fs-1">Kue Kering</div>
            <div class="card-body">
                <div class="row row-cols-1 row-cols-md-3 g-3">
                    @foreach ($product_best as $item)
                        <div class="col">
                            <div class="card">
                                <img src="{{ asset('assets/img/' . $item->image) }}" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">{{ $item->nama_product }}</h5>
                                    <p class="card-text">Rp{{ number_format($item->harga, 0, ',', '.') }}</p>
                                    <a href="/detail-product/{{ $item->id }}" class="btn btn-primary">More Detail</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="mt-2">
                    {{ $product_best->links() }}
                </div>
            </div>
        </div>
    @endauth
@endsection
