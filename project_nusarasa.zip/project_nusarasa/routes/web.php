<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Models\Product;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::class, 'index'])->middleware('guest');
Route::get('home', [HomeController::class, 'index'])->name('home')->middleware('auth');

Route::get('shop', [HomeController::class, 'shop'])->name('shop')->middleware('auth');
Route::get('shop/kategori/kue-kering', [HomeController::class, 'kategori_kue_kering'])->name('kategori_kue_kering')->middleware('auth');
Route::get('shop/kategori/kue-basah', [HomeController::class, 'kategori_kue_basah'])->name('kategori_kue_basah')->middleware('auth');
Route::get('shop/kategori/gorengan', [HomeController::class, 'kategori_gorengan'])->name('kategori_gorengan')->middleware('auth');

Route::get('search', [HomeController::class, 'search'])->name('search')->middleware('auth');

Route::resource('product', ProductController::class);
Route::get('product', [ProductController::class, 'index'])->name('product')->middleware('auth');
Route::get('add-item', [ProductController::class, 'create'])->name('add-item')->middleware('auth');
Route::post('add-item/store', [ProductController::class, 'store'])->middleware('auth');
Route::get('detail-product/{product:id}', [ProductController::class, 'show'])->middleware('auth');
Route::get('edit-product/{product:id}', [HomeController::class, 'show'])->middleware('auth');
Route::delete('product', [ProductController::class, 'destroy'])->middleware('auth');

Route::get('cart', [HomeController::class, 'cart'])->name('cart')->middleware('auth');
Route::get('checkout', [HomeController::class, 'checkout'])->name('checkout')->middleware('auth');
Route::get('checkout/store', [HomeController::class, 'checkout_action'])->name('checkout/store')->middleware('auth');

Route::get('history', [HomeController::class, 'history'])->name('history')->middleware('auth');

Route::get('profile', [ProfileController::class, 'index'])->name('index')->middleware('auth');
Route::get('edit-profile/{profile:id}', [ProfileController::class, 'edit'])->middleware('auth');
Route::post('edit-profile/{profile:id}', [ProfileController::class, 'update'])->middleware('auth');

Route::get('register', [LoginController::class, 'register'])->name('register')->middleware('guest');
Route::post('register', [LoginController::class, 'register_action'])->name('register.action');
Route::get('login', [LoginController::class, 'login'])->name('login')->middleware('guest');
Route::post('login', [LoginController::class, 'login_action'])->name('login.action')->middleware('guest');
Route::get('password', [HomeController::class, 'edit_password'])->name('password');
Route::post('password', [LoginController::class, 'password_action'])->name('password.action');
Route::get('logout', [LoginController::class, 'logout'])->name('logout');
